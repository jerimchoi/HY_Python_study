# Basic BigDataPractice(17.11.01)
BigData basic practice with LendingClub open data.  
Anaconda(python 3.x) required.
#### Detail explanation for codes and background theory will be provided on offline class.
___
### Files description
LendingClub fully paid bond classification.ipynb : Jupyter notebookd code  
dataset.csv : Training set  
test_dataset.csv : Test set  
utils.py : Pre-written codes for concise progress  
variable_description.xlsx : Feature description
